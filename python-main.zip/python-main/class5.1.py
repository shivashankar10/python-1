def priya():
    result"this is my balance"
test_dict={"fname":priya,"age":50,"address":"salem"}
print("the original dictionary is:"+str(test_dict))
res=test_dict['fname']()
print("the required call result:"+str(res))