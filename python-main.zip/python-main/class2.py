'''if(5>10):
    print("yes")
else:
    print("no")'''
'''age1=int(input('enter age1:'))
age2=int(input('enter age2:'))
if(age1>age2):
    age3=age1+age2
    print('my age added',age3)
else:
    age3=age1-age2
    print('my age subtracted',age3)'''
'''email="sanjay@gmail.com"
pwd=1234
uemail=str(input("enter the email"))
upwd=int(input("enter the pwd"))
if(email == uemail and pwd==upwd):
    print("login success")
else:
    print("login failed")'''

'''email="sanjay@gmail.com"
pwd=1234
uemail=str(input("enter the email"))
upwd=int(input("enter the pwd"))
if(email == uemail):
    if(pwd == upwd):
        print("login success")
    else:
        print("login failed due to incorrect pwd")
else:
    print("login failed due to incorrect email")'''
     
     
'''mob=9113563655
otp=12345
umob = int(input("enter the mob no"))
uotp = int(input("enter the otp"))
if(mob == umob):
    if(otp == uotp):
        print("transaction success")
    else:
        print("transation declained due to incorrect otp")
else:
    print("transaction declained due to incorrect mob")'''

'''num1=int(input("enter the num1:"))
num2=int(input("enter the num2:"))
if(num1>num2):
    print(num1,'num1 is greater')
elif(num1==num2):
    print('both r equal')
else:
    print(num2,'num2 is greater')'''

a=50
b=10
c=-15
print('a' if a>b and a>c else 'b' if b>c else 'c')
    