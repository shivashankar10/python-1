class Mango:
    def _init_(self):
        print("this is what?")
    def sanjay(self):
        print("this is without para")
    def shaid(self,a,b):
        print(a+b,"this is with para")
    def magicalprime(self,a):
        print("check it magical prime or not")
    def neon(self,a):
        print("check neon or not")
man=Mango()
man.sanjay()
man.shaid(10,20.5)
man.magicalprime(101)
man.neon(7)