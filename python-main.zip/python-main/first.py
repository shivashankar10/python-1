name=float(input("enter name:"))
print(name)
print (type(name))
